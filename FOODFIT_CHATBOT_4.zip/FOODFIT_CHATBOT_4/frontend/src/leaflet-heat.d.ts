declare module "leaflet.heat";
