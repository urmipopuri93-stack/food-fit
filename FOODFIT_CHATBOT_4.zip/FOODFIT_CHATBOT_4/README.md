# food-fit
## FoodFit assistant (map-aware chatbot)

The `/heatmap` page includes FitBasket, a chatbot that explains the map, moves it to Texas counties or tracts, summarizes or compares FoodFit data, finds food-assistance resources, and finds **service gaps**: high-need tracts far from any listed food resource. It works without IBM credentials using a built-in deterministic assistant. IBM watsonx.ai is optional and is reached through the small server in `chat-api/`, so the API key stays server-side. See [`chat-api/README.md`](chat-api/README.md) for the response contract, how map actions are verified, environment variables and every test command.

## Project structure

```
FOODFITAI_2/
├── chat-api/                 FastAPI server (port 8001): /api/chat, /api/health, /api/resources/*
│   ├── main.py               routing, validation, rate limits, optional static hosting of frontend/dist
│   ├── rules.py              built-in assistant: intents, county matching against the map GeoJSON, answer composer
│   ├── assistant.py          response contract (message, intent, map_action, geography, data, suggestions, source, error)
│   ├── tools.py              allowlisted tools + system prompt for watsonx
│   ├── watsonx.py            optional IBM watsonx.ai client
│   ├── resources/            food-resource list (snapshot JSON) and search service
│   ├── smoke_test.py         end-to-end API check, no credentials needed
│   ├── test_*.py             pytest suites (test_phase5.py = map actions + contract)
│   └── dev/fake_watsonx.py   TEST-ONLY scripted model for browser tests
├── frontend/                 React + Vite + Leaflet (port 5173)
│   ├── src/HeatmapPage.tsx   the /heatmap map page
│   ├── src/chat/             FitBasket: ChatPanel, chatClient, mapController (verified map actions),
│   │                         chatBridge (map <-> chat, selected-county highlight), serviceGaps, tractIndex
│   ├── src/resources/        resource panel, markers, API client, chat resource tools
│   ├── public/data/texas_heatmap.geojson   5,238 Texas census tracts with need scores
│   ├── tests/                vitest + Testing Library (phase5.test.tsx drives a real Leaflet map)
│   └── e2e/                  Playwright browser tests (phase5.spec.ts = acceptance scenarios)
├── ml/  data/                model pipeline and source data
```

## Run FoodFit on macOS

Requirements: **Python 3.10+** (the system `python3` on macOS is 3.9, so install one with `brew install python@3.12`) and **Node.js 20.19+ or 22.12+** (`node -v`).

**Terminal A: backend (FastAPI on port 8001)**
```bash
cd /Users/asad/Downloads/FOODFITAI_2/chat-api
python3.12 -m venv .venv                   # first time only
source .venv/bin/activate
pip install -r requirements.txt -r requirements-dev.txt
cp -n .env.example .env                    # first time only; add WATSONX_* values only if you want the AI model
uvicorn main:app --port 8001 --reload
```

**Terminal B: frontend (Vite on port 5173)**
```bash
cd /Users/asad/Downloads/FOODFITAI_2/frontend
npm ci                                     # first time, or after package changes
npm run dev
```
Open **http://localhost:5173/heatmap**. Vite forwards `/api` to port 8001.

**Health checks** (Terminal C):
```bash
curl -s http://127.0.0.1:8001/api/health                                   # backend
curl -s -o /dev/null -w "%{http_code}\n" http://localhost:5173/heatmap      # frontend: 200
curl -s http://localhost:5173/api/health                                   # backend through the Vite proxy
cd /Users/asad/Downloads/FOODFITAI_2/chat-api && source .venv/bin/activate && python smoke_test.py
```
`"assistant": "built-in rules only"` means watsonx isn't configured. FitBasket still works and labels its answers "Answered by FitBasket's built-in assistant".

### Verify Dallas County navigation by hand
1. Open http://localhost:5173/heatmap and wait for the map to colour in.
2. Click the FitBasket button (bottom right) and send **Show me Dallas County on the map**.
3. Expected: a green **Map moved to Dallas County** status, the map zoomed to Dallas County with its tracts outlined in dark lines, and an answer saying its 528 census tracts are shaded. You should see no red "The map did not change" box.
4. Send **Show me Collin County**: the map moves north and the outline moves to Collin. Send **Show me all of Texas**: the full state is back and the outline is cleared.
5. Optional, in DevTools: inspect the map `<div class="heatmap-map">`. Its `data-zoom`, `data-center`, `data-bounds` and `data-selected-county` attributes show the live viewport.

### Run all checks
```bash
cd /Users/asad/Downloads/FOODFITAI_2/frontend
npm ci && npm run lint && npm run build && npm test && npm run typecheck:test
cd ../chat-api && source .venv/bin/activate
pytest -q
python smoke_test.py                       # needs Terminal A running
```
Browser (Playwright) tests are in `chat-api/README.md` → Testing.

### Troubleshooting
| Symptom | Fix |
|---|---|
| `FoodFit chat-api needs Python 3.10 or newer` | Create the venv with `python3.12` (see above). |
| `[Errno 48] Address already in use` on 8001 or 5173 | See what holds the port: `lsof -nP -iTCP:8001 -sTCP:LISTEN`. If it's an old uvicorn or Vite from this project, stop it with Ctrl+C in its terminal, or `kill <PID>` for that PID only. Don't use `killall`. |
| Chat says "can't reach the FoodFit assistant service" | Terminal A isn't running, or isn't on port 8001. Check `curl http://127.0.0.1:8001/api/health`. |
| "The map did not move to the requested county." | Fixed in Phase 5: it was a false alarm on wide windows (see `chat-api/README.md` → "Diagnosing map-action failures"). If you still see it, make sure both servers run the updated code: restart uvicorn and Vite, then hard-reload the page. |
| Answers say "built-in assistant" but you set watsonx keys | `curl …/api/health` shows `ai_missing` and `env_file_found`. The file must be `chat-api/.env`, and you must restart uvicorn after editing it. |
| "couldn't sign in to the AI model" notice | `WATSONX_API_KEY` is invalid or expired, or `WATSONX_URL` is the wrong region. |
| Map loads but no tiles | Map tiles come from OpenStreetMap and need internet access. The data layers still work. |

To deploy as a single process, see "Deploying" in [`chat-api/README.md`](chat-api/README.md).
